//variables//
let ballx;
let bally;
let balldiameter;

function setup() {
  createCanvas(400, 400);
   background(227);
  ballx = random(20,400)
  bally =random(20,400)
  balldiameter = 20
  //determine if the ball is ofscreen or not and place it back on canvas//
    circle (ballx,bally,balldiameter)}


function draw() {
  frameRate(120)
  background(227);
  // use === to check if a variable equals an location//
  if(ballx === 200){}
  ballx+=0;
  bally+=1;
circle (ballx,bally,balldiameter);
if(bally>400||ballx>400){
  ballx=random(20,400);
bally=random(20,400);}
  else{
    fill(int(random(0,256),random(0,256),random(0,256)))
  }
  if(bally<220){
    ballx+=5
    }
  
}