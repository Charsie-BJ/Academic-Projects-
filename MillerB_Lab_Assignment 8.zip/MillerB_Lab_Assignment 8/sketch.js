let img1;
let img2;
let img3;
let font;
//to load the image.

function preload () {
//Origional imgage by u/Objective-Side-524 on Reddit https://www.reddit.com/r/cats/comments/udd8zg/love/
img1 = loadImage ('/assets/Two Cats.jpg');
//Origional image by Laura, a quilter and pattern designer https://www.sliceofpiquilts.com/2021/01/heart-postage-stamp-free-quilt-block.html
img2 = loadImage ('/assets/Heart Stamp.jpg');
//
img3 = loadImage ('/assets/Textbubble.png');
font = loadFont('/assets/Fonts/Love.ttf');
//Love font by Vladimir Nikolic
}

//must preload image before draw runs!




function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
scale(.6);
image(img1, 0, -30);
//Stamp image
scale(.09);
image(img2, 210, 200);
//textbubble
scale(7);
image(img3,30, 770);


//make text say 'lovers furrever!'
  fill(230, 30, 110);
  stroke(80, 15, 40);
  scale(5.6);
  textFont(font);
  textSize(10);
  strokeWeight(1.5);
  let textmsg = 'An unfurrgetable message to my purrfect match <3 !'
  text(textmsg, 75, 13, 130, 600);

 
}