let foodgood = ["Italian", "American Food","Southern BBQ", "Chinese", "Five Guys", "Soup"];
let foodbad = ["Uranium", "Volcanic Ash", "Cottage Cheese", "Pufferfish", "Batteries", "Rocks"]
console.log (foodgood);
console.log (foodbad)
let dafood = [];
let dafoodX = [];
let dafoodY = [];
function setup() {
  createCanvas(400, 400);
    background(30);
for (let p = 0; p<8; p++){
let num = Math.floor(random(0,foodgood.length));  
dafood.push( foodgood[num],foodbad[num]);
dafoodX.push(random(150,165));
dafoodY.push(random(50, height-68));
}  
//INSTRUCTIONS:make 2 arrays, then print them on the screen,
//GOAL: Seperate food into 2 arrays

for (let i = 0; i<dafood.length; i++){
fill(225);
textSize(14)
text(dafood[i], dafoodX[i], dafoodY[i]);

}  
}

function draw() {
  
rect(400,200,5,200);
  
noStroke()
rect(50,80,20,150);
triangle(100,210,60,260,20,210);

noStroke()
  fill(50,200,130);
rect(330,110,20,150);
triangle(300,130,340,80,380,130);  
  
  
  
  
  
  
  
//Top text
  textSize(24)
  fill(50,200,130);
  stroke(8);
  text('Should ABSOLUTELY eat today ^^', 15, 30);
  //Bottom text
  textSize(20)
  fill(200,50,130);
  stroke(8);
  let textw = 'Do not eat this today or The Doomsday Clock gets pushed forward by 20 seconds!';
  text(textw, 15, 325, 390, 400);
}